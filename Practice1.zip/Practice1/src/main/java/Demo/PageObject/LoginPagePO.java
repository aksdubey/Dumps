package Demo.PageObject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import Utilities.ConfigProvider;
import io.github.bonigarcia.wdm.DriverManagerType;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPagePO {

	private static WebDriver driver;

	public LoginPagePO() {

		WebDriverManager.getInstance(DriverManagerType.CHROME).setup();
		// System.setProperty("webdriver.chrome.driver",ConfigProvider.configFileReader("ChromeDriverPath"));
		driver = new ChromeDriver();
	}
	
	
	public LoginPagePO(String Browser) {

		if(Browser.equals("Chrome"))
		{
			WebDriverManager.getInstance(DriverManagerType.CHROME).setup();
		// System.setProperty("webdriver.chrome.driver",ConfigProvider.configFileReader("ChromeDriverPath"));
			driver = new ChromeDriver();
		}
		else if(Browser.equals("Firefox")) {
			WebDriverManager.getInstance(DriverManagerType.FIREFOX).setup();
			driver = new FirefoxDriver();
		}else {
			WebDriverManager.getInstance(DriverManagerType.IEXPLORER).setup();
			driver = new InternetExplorerDriver();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}
	
	

	public WebDriver getDriver() {
		return driver;
	}

	public enum FIELDS {

		HelpLink(By.xpath("")), FD_Type(By.id("ddlTypeOfFixedDeposit")), Amount(By.id("loanAmount")), lblMaturityValue(
				By.id("spnMaturityValue")), LblAggregateInterest(By.id("spnAIAmount")),
		DaysOnlyRadio(By.id("idDays")),
		DaysInput(By.id("tenureDay")),companyLogo(By.xpath("//*[@class='Logo']"));
		private By findby;

		FIELDS(By findby) {
			this.findby = findby;
		}
	}

	public void navigateToHomeUrl(String Url) throws InterruptedException {
		driver.get(Url);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.switchTo().frame(driver.findElement(By.id("paymframe")));
	}

	public void clickOnCheckEmi() {
		driver.findElement(FIELDS.HelpLink.findby).click();
	}

	public void selectfdType(String option) {

		driver.findElement(FIELDS.FD_Type.findby).sendKeys(option);
	}

	public void enterloanAmount(String amt) {
		// System.out.println(driver.findElement(FIELDS.Amount.findby).getText());
		driver.findElement(FIELDS.Amount.findby).click();
		driver.findElement(FIELDS.Amount.findby).clear();
		driver.findElement(FIELDS.Amount.findby).sendKeys(amt);
		driver.findElement(FIELDS.Amount.findby).sendKeys(Keys.TAB);
	}

	public void getMaturityValue() {
		System.out.println(driver.findElement(FIELDS.lblMaturityValue.findby).getText());
	}

	public void getAggregateInterest() {
		System.out.println(driver.findElement(FIELDS.LblAggregateInterest.findby).getText());
	}
	
	public void selectDaysOnlyTenure() {
		driver.findElement(FIELDS.DaysOnlyRadio.findby).click();
	}
	public void enterDays(String days) {
		driver.findElement(FIELDS.DaysInput.findby).clear();
		driver.findElement(FIELDS.DaysInput.findby).sendKeys(days);
		driver.findElement(FIELDS.Amount.findby).sendKeys(Keys.TAB);
	}
	public void clickLogo()
	{
		driver.navigate().refresh();
		driver.findElement(FIELDS.companyLogo.findby).click();
	}
	
}
