package tMobile.Tests;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import Utilities.ConfigProvider;
import tMobile.PO.tMobileHomePo;

public class TC001_tMobileTest1_001 {

	tMobileHomePo homepage;
	@Test
	public void TC001(){
		
		homepage = new tMobileHomePo("Chrome");
		homepage.navigateToUrl(ConfigProvider.configFileReader("tmobile.home.url"));
		homepage.navigateToPhone();
		homepage.Filter("New");
		homepage.clickOnAccessories();
	}
	
	@AfterClass
	public void closeDriver() {
		homepage.quit();
	}
}
